document.addEventListener("DOMContentLoaded", function () {
    const rows = document.querySelectorAll("tbody tr");

    rows.forEach(row => {
        row.addEventListener("mouseover", () => {
            row.style.backgroundColor = "#aaa";
        });

        row.addEventListener("mouseout", () => {
            row.style.backgroundColor = "";
        });
    });
});