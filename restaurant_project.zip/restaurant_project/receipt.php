<?php
include 'db_connect.php';

if (isset($_GET['order_id'])) {
    $order_id = intval($_GET['order_id']);
    $query = "SELECT * FROM order1 WHERE id = $order_id";
    $result = mysqli_query($conn, $query);
    $order = mysqli_fetch_assoc($result);

    if (!$order) {
        die("Order not found.");
    }
} else {
    die("Invalid request.");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receipt - Order #<?php echo $order['id']; ?></title>
    <link rel="stylesheet" href="receipt.css">
</head>
<body>
	<a href="revenue.php" class="home-btn">(---</a>
    <div class="receipt-container">
        <div class="receipt">
            <div class="header">
                <h2>The Table</h2>
                <p>📍 Address | ☎ Contact</p>
            </div>
            <hr>
            <div class="details">
                <p><strong>Order ID:</strong> <?php echo $order['id']; ?></p>
                
                <p><strong>Date & Time:</strong> <?php echo $order['order_date']; ?></p>
            </div>
            <hr>
            <table class="items">
                <thead>
                    <tr>
                        <th>Item</th>
                        <th>Qty</th>
                        <th>Price</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $prices = ['burger' => 150, 'pizza' => 200, 'pasta' => 80, 'coffee' => 50];
                    $subtotal = 0;
                    foreach ($prices as $item => $price) {
                        $qty = $order[$item . '_qty'];
                        if ($qty > 0) {
                            $total = $qty * $price;
                            echo "<tr><td>" . ucfirst($item) . "</td><td>$qty</td><td>₹$total</td></tr>";
                            $subtotal += $total;
                        }
                    }
                    $tax = $subtotal * 0.05;
                    $total_price = $subtotal + $tax;
                    ?>
                </tbody>
            </table>
            <hr>
            <div class="summary">
                <p><strong>Subtotal:</strong> ₹<?php echo number_format($subtotal, 2); ?></p>
                <p><strong>Tax (5%):</strong> ₹<?php echo number_format($tax, 2); ?></p>
                <h3><strong>Total: ₹<?php echo number_format($total_price, 2); ?></strong></h3>
            </div>
            <hr>
            <p class="payment-method">Payment Method: Cash</p>
            <p class="thank-you">Thank you for dining with us! 🍽️</p>
            <button onclick="window.print()" class="print-btn">Print Receipt</button>
        </div>
    </div>
</body>
</html>