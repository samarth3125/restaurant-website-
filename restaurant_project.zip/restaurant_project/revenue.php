<?php
include 'db_connect.php';

// Get selected date or default to today's date
$date_filter = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');

// Fetch orders for the selected date
$sql = "SELECT * FROM order1 WHERE DATE(order_date) = '$date_filter' ORDER BY order_date DESC";
$result = $conn->query($sql);

// Calculate total revenue
$total_revenue = 0;
$orders = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $orders[] = $row;
        $total_revenue += $row['total_price'];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Revenue Report</title>
    <link rel="stylesheet" href="revenue.css">
</head>
<body>
	<a href="index.html" class="home-btn">🏠 Home</a>
    <div class="container">
        <h1>📊 Revenue Report</h1>

        <!-- Date Filter -->
        <form method="GET" action="revenue.php">
            <input type="date" id="date" name="date" value="<?= $date_filter ?>">
            <button type="submit">Filter</button>
        </form>

        <!-- Total Revenue -->
        <div class="total-revenue">
            <h2>Total Revenue: ₹<?= number_format($total_revenue, 2) ?></h2>
        </div>

        <!-- Revenue Table -->
        <table>
            <tr>
                <th>Order ID</th>
                <th>Burger Qty</th>
                <th>Pizza Qty</th>
                <th>Pasta Qty</th>
                <th>Coffee Qty</th>
                <th>Total Price</th>
                <th>Order Date</th>
                <th>Receipt</th>
            </tr>
            <?php foreach ($orders as $order): ?>
            <tr>
                <td><?= $order['id'] ?></td>
               
                <td><?= $order['burger_qty'] ?></td>
                <td><?= $order['pizza_qty'] ?></td>
                <td><?= $order['pasta_qty'] ?></td>
                <td><?= $order['coffee_qty'] ?></td>
                <td>₹<?= number_format($order['total_price'], 2) ?></td>
                <td><?= $order['order_date'] ?></td>
                <td><a href="receipt.php?order_id=<?= $order['id'] ?>" class="btn-receipt">🧾 Generate</a></td>
            </tr>
            <?php endforeach; ?>
        </table>
    </div>
</body>
</html>