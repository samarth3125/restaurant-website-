<?php
// Database connection
$conn = new mysqli('localhost', 'root', '', 'restaurant_order');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data
$table_number = isset($_POST['table_number']) ? intval($_POST['table_number']) : 0;
$burger_qty = isset($_POST['burger_qty']) ? intval($_POST['burger_qty']) : 0;
$pizza_qty = isset($_POST['pizza_qty']) ? intval($_POST['pizza_qty']) : 0;
$pasta_qty = isset($_POST['pasta_qty']) ? intval($_POST['pasta_qty']) : 0;
$coffee_qty = isset($_POST['coffee_qty']) ? intval($_POST['coffee_qty']) : 0;

// Validate table number
if ($table_number < 1 || $table_number > 10) {
    die("Invalid table number. Please enter a value between 1 and 10.");
}

// Calculate total price
$total_price = ($burger_qty * 150) + ($pizza_qty * 300) + ($pasta_qty * 80) + ($coffee_qty * 50);

// Insert order into the database
$sql = "INSERT INTO orders (table_number, burger_qty, pizza_qty, pasta_qty, coffee_qty, total_price) 
        VALUES ('$table_number', '$burger_qty', '$pizza_qty', '$pasta_qty', '$coffee_qty', '$total_price')";

if ($conn->query($sql) === TRUE) {
    echo "Order placed successfully! <a href='order.html'>Place another order</a>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>