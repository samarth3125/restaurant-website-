<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "online";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$burger_qty = $_POST['burger_qty'];
$pizza_qty = $_POST['pizza_qty'];
$pasta_qty = $_POST['pasta_qty'];
$coffee_qty = $_POST['coffee_qty'];

$burger_price = 150;
$pizza_price = 200;
$pasta_price = 80;
$coffee_price = 50;

$total_price = ($burger_qty * $burger_price) + ($pizza_qty * $pizza_price) + 
               ($pasta_qty * $pasta_price) + ($coffee_qty * $coffee_price);
			   
if($burger_qty>0||$pizza_qty>0||$pasta_qty>0||$coffee_qty>0)
{
$sql = "INSERT INTO order1(burger_qty, pizza_qty, pasta_qty, coffee_qty, total_price) 
        VALUES ('$burger_qty', '$pizza_qty', '$pasta_qty', '$coffee_qty', '$total_price')";

if ($conn->query($sql) === TRUE) {
    echo "<script>alert('Order placed successfully!'); window.location.href='order.html';</script>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}}

else{
	 echo "<script>alert('No item selected');  window.location.href='order.html';</script>";
}
$conn->close();
?>